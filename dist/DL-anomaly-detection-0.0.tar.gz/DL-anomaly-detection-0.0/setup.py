from setuptools import setup, find_packages
 
setup(name='DL-anomaly-detection',
      version='0.00',
      url='https://github.com/waico/DL-anomaly-detection/',
      license=' BSD-3-Clause License',
      #packages=find_packages(),
      packages=['DL-anomaly-detection'],
      author='Vyacheslav Kozitsin, Iurii Katser',
      author_email='rfptk2525@yandex.ru',
      description='Build librarry',
      #packages=find_packages(exclude=['tests']),
      #long_description=open('README.md').read(),
      long_description_content_type='text/x-rst',
      install_requires=['numpy','pandas','sympy','sklearn','statsmodels'], # install_requires=[ 'A>=1,<2', 'B>=2']
      zip_safe=False)